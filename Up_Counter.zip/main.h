#ifndef MAIN_H
#define MAIN_H

/* The pin map for CLCD, Using 4 Bit mode with RW grounded */
#define D4      32
#define D5      33
#define D6      27
#define D7      14
#define RS      25
#define EN      26

#endif
